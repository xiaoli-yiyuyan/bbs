<?php component('/components/common/left_menu'); ?>

<header class="header-bar">
    <div class="header-item left-menu">
        <i class="icon-svg svg-menu"></i>
    </div>
    
    <div class="header-title"><?=$title?></div>
    
    <div class="header-item">
        <a href="/message"><i class="icon-svg svg-mail"></i></a>
    </div>
</header>