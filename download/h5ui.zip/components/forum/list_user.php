<div class="bbs_user"><img class="bbs_user_photo" src="<?=$userinfo['photo']?>" alt=""> <?=$userinfo['nickname']?></div>
