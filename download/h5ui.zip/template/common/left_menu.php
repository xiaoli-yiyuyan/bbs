<div class="left-menu-list">
    <div class="modal-overlay"></div>
    <div class="menu-list-body">
    <div class="list">
            <div class="list-group list-arrow">
                <a href="/" class="list-item ellipsis">社区首页</a>
                <a href="/user/index" class="list-item ellipsis">个人中心</a>
                <a href="/user/friend" class="list-item ellipsis">我的好友</a>
                <!-- <div class="list-item ellipsis">消息列表</div>
                <div class="list-item ellipsis">论坛大厅</div> -->
            </div>
        </div>
    </div>
</div>