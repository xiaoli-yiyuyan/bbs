<div class="bbs_page">
    <div class="bbs_page_action">
        <div class="bbs_page_jump_box">
            <a class="bbs_page_jump" href="<?=$page['href'][0]?>">首页</a>
            <a class="bbs_page_jump" href="<?=$page['href'][1]?>">上页</a>
            <input type="text" class="input bbs_page_jump" placeholder="<?=$page['page']?>/<?=$page['page_count']?>">
            <a class="bbs_page_jump" href="<?=$page['href'][2]?>">下页</a>
            <a class="bbs_page_jump" href="<?=$page['href'][3]?>">尾页</a>
        </div>
    </div>
</div>