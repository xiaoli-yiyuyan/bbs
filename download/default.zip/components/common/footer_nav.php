<footer class="h5ui-bar bar-fixed">
    <a href="" class="h5ui-bar_item active">
        <i class="h5ui-bar_icon">
            <img src="http://s.h5ui.io/img/mark-green.png" width="100%">
        </i>
        <span>首页</span>
    </a>
    <a href="" class="h5ui-bar_item">
        <i class="h5ui-bar_icon">
            <img src="http://s.h5ui.io/img/mark.png" width="100%">
            <span class="h5ui-badge h5ui-badge_dot"></span>
        </i>
        <span>动态</span>
    </a>
    <a href="" class="h5ui-bar_item">
        <i class="h5ui-bar_icon">
            <img src="http://s.h5ui.io/img/mark.png" width="100%">
        </i>
        <span>发起</span>
    </a>
    <a href="" class="h5ui-bar_item">
        <i class="h5ui-bar_icon">
            <img src="http://s.h5ui.io/img/mark.png" width="100%">
            <span class="h5ui-badge">8</span>
        </i>
        <span>我</span>
    </a>
</footer>