<style>
a[title='站长统计'] {
    display: none;
}
</style>
<script src="https://s22.cnzz.com/z_stat.php?id=1260236179&web_id=1260236179" language="JavaScript"></script>
</body>
</html>