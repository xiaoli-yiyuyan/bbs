<div class="bottom-box">
    <div class="flex-box">
        <div class="item">
            <mu-ripple/>
            <div class="icon-svg svg-x-like"></div>
            <div class="grid-cell">推荐</div>
        </div>
        <div class="item">
            <mu-ripple/>
            <div class="icon-svg svg-x-lanmu"></div>
            <div class="grid-cell">论坛</div>
        </div>
        <div class="item">
            <mu-ripple/>
            <div class="icon-svg svg-x-kf"></div>
            <div class="grid-cell">个人</div>
        </div>
    </div>
</div>