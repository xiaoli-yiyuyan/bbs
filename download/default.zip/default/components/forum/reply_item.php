    <div class="list-group">
        <div class="bbs_info">
            <div class="bbs_user"><img class="bbs_user_photo" src="<?=$item['photo']?>" alt=""> <?=$item['nickname']?></div>
            <div class="create_time">
                <?=$item['create_time']?>
            </div>
        </div>
        <div class="list-item">
            <?=$item['context']?>
        </div>
    </div>