<?php
	\Iam\Response::json($file_upload);
?>