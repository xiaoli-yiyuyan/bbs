<div class="link_title">友链网站推荐</div>
<div class="index_link">
<a href="http://ianmi.com">安米社区</a>
</div>