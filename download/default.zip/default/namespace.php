<?php return array (
  'components' => 
  array (
    'common' => 
    array (
    ),
    'forum' => 
    array (
    ),
    'user' => 
    array (
    ),
  ),
) ?>