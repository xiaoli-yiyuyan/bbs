/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 50540
Source Host           : 127.0.0.1:3306
Source Database       : mmo_world

Target Server Type    : MYSQL
Target Server Version : 50540
File Encoding         : 65001

Date: 2016-07-23 15:06:40
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `vipbenefit`
-- ----------------------------
DROP TABLE IF EXISTS `vipbenefit`;
CREATE TABLE `vipbenefit` (
  `viplv` int(11) NOT NULL COMMENT 'VIP等级',
  `needrmb` int(11) DEFAULT NULL COMMENT '该等级需要累计充值的元宝数量',
  `itemboxid` int(11) DEFAULT NULL COMMENT '奖励银两',
  PRIMARY KEY (`viplv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of vipbenefit
-- ----------------------------
INSERT INTO `vipbenefit` VALUES ('1', '1', '901');
INSERT INTO `vipbenefit` VALUES ('2', '1', '902');
INSERT INTO `vipbenefit` VALUES ('3', '1', '903');
INSERT INTO `vipbenefit` VALUES ('4', '1', '904');
INSERT INTO `vipbenefit` VALUES ('5', '1', '905');
INSERT INTO `vipbenefit` VALUES ('6', '1', '906');
INSERT INTO `vipbenefit` VALUES ('7', '1', '907');
INSERT INTO `vipbenefit` VALUES ('8', '1', '908');
INSERT INTO `vipbenefit` VALUES ('9', '1', '909');
INSERT INTO `vipbenefit` VALUES ('10', '1', '910');
INSERT INTO `vipbenefit` VALUES ('11', '1', '911');
INSERT INTO `vipbenefit` VALUES ('12', '1', '912');
INSERT INTO `vipbenefit` VALUES ('13', '1', '913');
INSERT INTO `vipbenefit` VALUES ('14', '1', '914');
INSERT INTO `vipbenefit` VALUES ('15', '1', '915');
