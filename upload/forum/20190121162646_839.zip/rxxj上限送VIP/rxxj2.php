<?php
error_reporting(0); 
define("APP_PATH",dirname(__FILE__));
$url = explode('\\',__FILE__);  
$filename = end($url);  
$sid = intval($_GET['sid']);
$sid == 0 && $sid = 1;

//引入数据库文件
require(APP_PATH."/config.php");
require(APP_PATH."/pdo.php");
$c = $Config['db' . $sid];
$db = new db_pdo_mysql($c);
$i_success = 0;
$i_failed  = 0;

$charge_list = $db->getArray('select AccountId,guid,channel,arenaRank from mmo_character.characters where arenaRank = 1000');
if (!empty($charge_list)) {	
	$url = $c['api_host'];
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);//不直接输出response  

	foreach ($charge_list as $a) {
		$dj = $a['arenaRank'];
		//$jf = $a['jf'];
		$sql = "call mmo_accountdb.order_create(1, {$a['AccountId']}, 1, 1, {$a['guid']}, {$a['channel']});";
		$result = $db->callProc($sql);
		$order = $result[0];
	//	var_dump($result);exit;
		$data = array(
            'pid'	    => '41',
            'gid'	    => '1001015',
            'time'	    => time(),
            'oid'	    => '936742703',
            'doid'	    => $order['orderid'],
            'dsid'	    => $c['sid'],
            'drid'	    => $a['guid'],
            'drname'	=> 'hello',
            'drlevel'	=> '1',
            'uid'	    => $a['AccountId'],
            'money'	    => $dj / 10,
            'coin'	    => $dj,
            'paid'	    => ''
        );
        $data['sign'] = md5($data['time'] . $c['key'] . $data['oid'] . $data['doid'] . $data['dsid'] . $data['uid'] . $data['money'] . $data['coin']);
		curl_setopt($ch, CURLOPT_URL, $url . http_build_query($data));
		$return_content = curl_exec($ch);
		$insert_result = json_decode($return_content, true);
		//var_dump($insert_result);
        if($insert_result['state'] == 1) {			        
        	$db->exec("update mmo_character.characters set arenaRank = 999 where guid={$a['guid']}");
        	$i_success++;
        } else {
        	$i_failed++;
        }
	}
	curl_close($ch);
}		
echo '<title>'. $sid .'服充值刷新</title><meta charset="utf-8" /><meta http-equiv="refresh" content="40;url='. $filename .'?sid='. $sid .'"/> ';
echo "<b>更新时间:".date("Y-m-d H:i:s")."</b><br /><b>处理成功{$i_success}个账号数据,失败{$i_failed}个</b>";
